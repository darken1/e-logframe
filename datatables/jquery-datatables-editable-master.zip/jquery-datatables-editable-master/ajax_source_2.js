{ "aaData": [
	["Trident","Internet Explorer 4.0","Win 95+"],
	["Trident","Internet Explorer 5.0","Win 95+"],
	["Trident","Internet Explorer 5.5","Win 95+"],
	["Trident","Internet Explorer 6","Win 98+"],
	["Trident","Internet Explorer 7","Win XP SP2+"],
	["Misc","Links","Text only"],
	["Misc","Lynx","Text only"],
	["Misc","IE Mobile","Windows Mobile 6"],
	["Misc","PSP browser","PSP"],
	["Other browsers","All others","-"]
] }