{
  "sEcho": 1,
  "iTotalRecords": "57",
  "iTotalDisplayRecords": "57",
  "aaData": [
    {
      "DT_RowId": "row_7",
      "DT_RowClass": "gradeA",
      "0": "Gecko",
      "1": "Firefox 1.0",
      "2": "Win 98+ / OSX.2+",
      "3": "1.7",
      "4": "A"
    },
    {
      "DT_RowId": "row_8",
      "DT_RowClass": "gradeA",
      "0": "Gecko",
      "1": "Firefox 1.5",
      "2": "Win 98+ / OSX.2+",
      "3": "1.8",
      "4": "A"
    },
    {
      "DT_RowId": "row_9",
      "DT_RowClass": "gradeA",
      "0": "Gecko",
      "1": "Firefox 2.0",
      "2": "Win 98+ / OSX.2+",
      "3": "1.8",
      "4": "A"
    },
    {
      "DT_RowId": "row_10",
      "DT_RowClass": "gradeA",
      "0": "Gecko",
      "1": "Firefox 3.0",
      "2": "Win 2k+ / OSX.3+",
      "3": "1.9",
      "4": "A"
    },
    {
      "DT_RowId": "row_11",
      "DT_RowClass": "gradeA",
      "0": "Gecko",
      "1": "Camino 1.0",
      "2": "OSX.2+",
      "3": "1.8",
      "4": "A"
    },
    {
      "DT_RowId": "row_12",
      "DT_RowClass": "gradeA",
      "0": "Gecko",
      "1": "Camino 1.5",
      "2": "OSX.3+",
      "3": "1.8",
      "4": "A"
    },
    {
      "DT_RowId": "row_13",
      "DT_RowClass": "gradeA",
      "0": "Gecko",
      "1": "Netscape 7.2",
      "2": "Win 95+ / Mac OS 8.6-9.2",
      "3": "1.7",
      "4": "A"
    },
    {
      "DT_RowId": "row_14",
      "DT_RowClass": "gradeA",
      "0": "Gecko",
      "1": "Netscape Browser 8",
      "2": "Win 98SE+",
      "3": "1.7",
      "4": "A"
    },
    {
      "DT_RowId": "row_15",
      "DT_RowClass": "gradeA",
      "0": "Gecko",
      "1": "Netscape Navigator 9",
      "2": "Win 98+ / OSX.2+",
      "3": "1.8",
      "4": "A"
    },
    {
      "DT_RowId": "row_16",
      "DT_RowClass": "gradeA",
      "0": "Gecko",
      "1": "Mozilla 1.0",
      "2": "Win 95+ / OSX.1+",
      "3": "1",
      "4": "A"
    }
  ]
}