FormValudator = function () {

};

// tooltips
FormValudator._MSG = {};
FormValudator._MSG["MSG_1"] = "The <_TITLE_OF_FIELD_> is a required field!\n";
FormValudator._MSG["MSG_2"] = "The <_TITLE_OF_FIELD_> is a required field!\nPlease, enter a valid <_TITLE_OF_FIELD_>.";
FormValudator._MSG["MSG_3"] = "You have to sign <_TITLE_OF_FIELD_> box as checked!\n";
FormValudator._MSG["MSG_4"] = "The <_TITLE_OF_FIELD_> field must _TYPE_OF_FIELD_>!\nPlease, re-enter."
FormValudator._MSG["MSG_5"] = "The <_TITLE_OF_FIELD_> field must be match with _TYPE_OF_FIELD_!\nPlease, re-enter.";        
        
FormValudator._MSG["SNT_1"] = "value";
FormValudator._MSG["SNT_2"] = "a signed ";
FormValudator._MSG["SNT_3"] = "an unsigned ";
FormValudator._MSG["SNT_4"] = "an upper case";
FormValudator._MSG["SNT_5"] = "a positive ";
FormValudator._MSG["SNT_6"] = "a negative ";
FormValudator._MSG["SNT_7"] = "a normal case ";
FormValudator._MSG["SNT_8"] = "a lower case ";
FormValudator._MSG["SNT_9"] = "a ";
FormValudator._MSG["SNT_10"] = "be _SYB_TYPE_OF_FIELD_ numeric value";
FormValudator._MSG["SNT_11"] = "be _SYB_TYPE_OF_FIELD_ integer value";
FormValudator._MSG["SNT_12"] = "be _SYB_TYPE_OF_FIELD_ float(real) value";
FormValudator._MSG["SNT_13"] = "be _SYB_TYPE_OF_FIELD_ alphabetic value";
FormValudator._MSG["SNT_14"] = "be _SYB_TYPE_OF_FIELD_ text";
FormValudator._MSG["SNT_15"] = "be _PASS_LENGTH_ characters at least\nand consist of letters and digits";
FormValudator._MSG["SNT_16"] = "be _LOGIN_LENGTH_ characters at least,\nstart from letter and consist of letters or digits";
FormValudator._MSG["SNT_17"] = "be a zip(post) code value";
FormValudator._MSG['SNT_18'] = "be in email format";
FormValudator._MSG['SNT_19'] = "be _PASS_LENGTH_ characters at least";
FormValudator._MSG['SNT_20'] = "be a required type";
FormValudator._MSG['SNT_21'] = "be a valid URL";



