<?php
			$_alive['save'] = 0;
			$_alive['refresh'] = 1363308539;
			?>